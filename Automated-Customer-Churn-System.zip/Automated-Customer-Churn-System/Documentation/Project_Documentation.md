# Customer Churn Analysis System Documentation

## Project Title
Customer Churn Analysis System using Python, MySQL, and Power BI

---

## Project Overview
The Customer Churn Analysis System is a data analytics project developed to analyze customer behavior and identify churn patterns. The project uses Python for data preprocessing, MySQL for database management, and Power BI for interactive dashboard visualization.

The system helps businesses understand:
- Customer churn trends
- Revenue impact
- Risk categories
- Contract-based churn behavior
- Customer engagement patterns

---

## Technologies Used

| Technology | Purpose |
|------------|---------|
| Python | Data Cleaning & Processing |
| MySQL | Database Management |
| Power BI | Dashboard Visualization |
| Pandas | Data Manipulation |
| NumPy | Numerical Operations |

---

## Project Workflow

### Step 1: Data Collection
Customer churn dataset was collected in CSV format containing customer details such as:
- Gender
- Contract Type
- Monthly Charges
- Churn Status
- Customer Satisfaction
- Risk Category

---

### Step 2: Data Preprocessing using Python
Python was used for:
- Removing missing values
- Cleaning inconsistent data
- Creating risk categories
- Formatting columns
- Exporting cleaned data

Libraries used:
- pandas
- numpy

---

### Step 3: Database Management using MySQL
The cleaned dataset was imported into MySQL database.

Database Name:
churn_system

Main Table:
customers

SQL operations performed:
- Database creation
- Table creation
- User authentication
- Data querying

---

### Step 4: Dashboard Development using Power BI
Interactive dashboard was created using Power BI.

Dashboard includes:
- Total Customers KPI
- Total Revenue KPI
- Churn Customers KPI
- Average Monthly Charges KPI
- Risk Category Analysis
- Revenue Analysis
- Contract-based Churn Analysis
- Gender Filters
- Churn Filters

---

## Dashboard Insights

### Key Findings
- Majority of customers belong to Low Risk category.
- Month-to-Month contracts show higher churn rates.
- Churn customers contribute significantly to revenue loss.
- Average monthly charges vary based on contract type.

---

## Features of the System

- Interactive dashboard
- Real-time filtering
- Churn analysis
- Revenue analysis
- Customer segmentation
- Risk categorization

---

## Folder Structure

Automated-Customer-Churn-System
│
├── Data
├── Documentation
├── PowerBI
├── python
├── Reports
├── Screenshots
├── sql

---

## Conclusion
The Customer Churn Analysis System provides valuable business insights for customer retention strategies. By combining Python, MySQL, and Power BI, the project demonstrates end-to-end data analytics workflow and visualization techniques.

---

## Future Enhancements
- Machine Learning based churn prediction
- Automated email alerts
- Cloud database integration
- Real-time dashboard updates

---

## Developed By
Prasad Pediredla
import pandas as pd
from sqlalchemy import create_engine

# Load cleaned CSV data
df = pd.read_csv(
    "Data/Cleaned_data/cleaned_churn_data.csv"
)

# MySQL connection
engine = create_engine(
    "mysql+pymysql://projectuser:project123@localhost/churn_system"
)

# Upload data into SQL table
df.to_sql(
    name='customers',
    con=engine,
    if_exists='append',
    index=False
)

print("Data uploaded to MySQL successfully.")
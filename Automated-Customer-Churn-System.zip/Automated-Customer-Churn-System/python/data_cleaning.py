import pandas as pd

# Load Excel dataset
df = pd.read_excel(
    "Data/Raw_data/customer_churn_raw_data.xlsx.xlsx"
)

# Display first 5 rows
print(df.head())

# Remove duplicate rows
df.drop_duplicates(inplace=True)

# Fill missing values
df.fillna(0, inplace=True)

# Create automated risk category
df['Risk_Category'] = df.apply(
    lambda row: 'High Risk'
    if row['tenure'] < 12 and row['MonthlyCharges'] > 70
    else 'Low Risk',
    axis=1
)

# Export cleaned CSV file
df.to_csv(
    "Data/Cleaned_data/cleaned_churn_data.csv",
    index=False
)

print("Data cleaning automation completed successfully.")
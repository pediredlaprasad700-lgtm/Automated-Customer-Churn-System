import pandas as pd

# Load cleaned data
df = pd.read_csv(
    "Data/Cleaned_data/cleaned_churn_data.csv"
)

# Create churn summary
summary = df.groupby('Risk_Category').agg({
    'MonthlyCharges': 'mean',
    'customerID': 'count'
}).reset_index()

# Rename columns
summary.columns = [
    'Risk_Category',
    'Average_Monthly_Charges',
    'Customer_Count'
]

# Save processed analytics data
summary.to_csv(
    "Data/Processed_data/churn_summary.csv",
    index=False
)

print("Processed analytics data created successfully.")
-- Customer Churn Analysis Database Setup

CREATE DATABASE churn_system;

USE churn_system;

CREATE TABLE customers (
    customerID VARCHAR(50),
    gender VARCHAR(10),
    SeniorCitizen INT,
    Partner VARCHAR(10),
    Dependents VARCHAR(10),
    tenure INT,
    PhoneService VARCHAR(10),
    InternetService VARCHAR(50),
    Contract VARCHAR(50),
    PaymentMethod VARCHAR(50),
    MonthlyCharges FLOAT,
    TotalCharges FLOAT,
    Customer_Satisfaction INT,
    Complaint_Count INT,
    Last_Login_Days INT,
    Offer_Accepted VARCHAR(10),
    Churn VARCHAR(10),
    Risk_Category VARCHAR(20)
);

-- Create User

CREATE USER 'projectuser'@'localhost'
IDENTIFIED BY 'project123';

GRANT ALL PRIVILEGES
ON churn_system.*
TO 'projectuser'@'localhost';

FLUSH PRIVILEGES;

-- View Sample Data

USE churn_system;

SELECT * FROM customers LIMIT 10;

-- Configure Authentication

ALTER USER 'projectuser'@'localhost'
IDENTIFIED WITH mysql_native_password
BY 'project123';

FLUSH PRIVILEGES;

-- Analysis Queries

SELECT COUNT(*) AS Total_Customers
FROM customers;

SELECT Churn, COUNT(*) AS Customer_Count
FROM customers
GROUP BY Churn;

SELECT Contract, COUNT(*) AS Customer_Count
FROM customers
GROUP BY Contract;

SELECT AVG(MonthlyCharges) AS Average_Monthly_Charges
FROM customers;

SELECT Risk_Category, COUNT(*) AS Customers
FROM customers
GROUP BY Risk_Category;